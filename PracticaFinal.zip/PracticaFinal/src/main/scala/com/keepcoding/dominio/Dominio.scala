package com.keepcoding.dominio

case class Geolocalizacion(latitud:Double, longitud:Double, ciudad:String, pais:String)

case class Transaccion(dni:Long, importe:Double, descripcion:String, categoria:String, tarjetaCredito:String,
                         geolocalizacion:Geolocalizacion, fecha:String)

case class Cliente(dni:Long, nombre:String, cuentaCorriente:Int)

