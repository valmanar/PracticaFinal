package com.keepcoding.dominio

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.streaming.dstream.DStream

class Consultas {

  def agruparTransaccionesClientesCiudad(rddstream: RDD[Array[String]], sparkSession: SparkSession) = {

    val dfClientes = rddstream.map(event => {
      //pongo como id de cliente y transaccion el codigo de cuenta
      Cliente(event(6).toInt, event(4).toString, event(6).toInt)
    })

    val dfTransacciones = rddstream.map(event => {
      //pongo como id de cliente y transaccion el codigo de cuenta
      Transaccion(event(6).toInt, event(2).toDouble, event(10).toString, "N/A", event(3).toString,
        Geolocalizacion(event(8).toDouble, event(9).toDouble, event(5).toString, "N/A"), event(0).toString)
    })

    val sc = sparkSession.sparkContext

    val dfClientesD = sparkSession.createDataFrame(dfClientes)
    val dfTransaccionesD = sparkSession.createDataFrame(dfTransacciones)

    dfClientesD.createOrReplaceGlobalTempView("CLIENTES")
    dfTransaccionesD.createOrReplaceGlobalTempView("TRANSACCIONES")

    val transaccionesClientesCiudades = sparkSession.sql("SELECT c.nombre, TRIM(t.geolocalizacion.ciudad) AS ciudad, count(t.dni) AS transacciones  FROM global_temp.TRANSACCIONES t JOIN global_temp.CLIENTES c ON (t.dni=c.dni)" +
      "GROUP BY c.nombre, t.geolocalizacion.ciudad")

    transaccionesClientesCiudades

  }


  def pagoSuperiorA(rddstream: RDD[Array[String]], sparkSession: SparkSession) = {

    val dfClientes = rddstream.map(event => {
      //pongo como id de cliente y transaccion el codigo de cuenta
      Cliente(event(6).toInt, event(4).toString, event(6).toInt)
    })

    val dfTransacciones = rddstream.map(event => {
      //pongo como id de cliente y transaccion el codigo de cuenta
      Transaccion(event(6).toInt, event(2).toDouble, event(10).toString, "N/A", event(3).toString,
        Geolocalizacion(event(8).toDouble, event(9).toDouble, event(5).toString, "N/A"), event(0).toString)
    })

    val sc = sparkSession.sparkContext

    val dfClientesD = sparkSession.createDataFrame(dfClientes)
    val dfTransaccionesD = sparkSession.createDataFrame(dfTransacciones)

    dfClientesD.createOrReplaceGlobalTempView("CLIENTES")
    dfTransaccionesD.createOrReplaceGlobalTempView("TRANSACCIONES")

    val pagosSuperiores = sparkSession.sql("SELECT c.nombre FROM global_temp.TRANSACCIONES t JOIN global_temp.CLIENTES c ON (t.dni=c.dni)" +
      "WHERE t.importe > 3000 ORDER BY c.nombre")
    pagosSuperiores

  }


  def transaccionesClientesNuevaYork(rddstream: RDD[Array[String]], sparkSession: SparkSession) = {

    val dfClientes = rddstream.map(event => {
      //pongo como id de cliente y transaccion el codigo de cuenta
      Cliente(event(6).toInt, event(4).toString, event(6).toInt)
    })

    val dfTransacciones = rddstream.map(event => {
      //pongo como id de cliente y transaccion el codigo de cuenta
      Transaccion(event(6).toInt, event(2).toDouble, event(10).toString, "N/A", event(3).toString,
        Geolocalizacion(event(8).toDouble, event(9).toDouble, event(5).toString, "N/A"), event(0).toString)
    })

    val sc = sparkSession.sparkContext

    val dfClientesD = sparkSession.createDataFrame(dfClientes)
    val dfTransaccionesD = sparkSession.createDataFrame(dfTransacciones)

    dfClientesD.createOrReplaceGlobalTempView("CLIENTES")
    dfTransaccionesD.createOrReplaceGlobalTempView("TRANSACCIONES")

    //Tarea 4 Transacciones por cliente con ciudad New York
    val clientesNewYork = sparkSession.sql("SELECT c.nombre, COUNT(t.dni)  FROM global_temp.TRANSACCIONES t JOIN global_temp.CLIENTES c ON (t.dni=c.dni) WHERE TRIM(t.geolocalizacion.ciudad) = 'New York' GROUP BY c.nombre")

    clientesNewYork

  }


  def transaccionesCategoriaOcio(rddstream: RDD[Array[String]], sparkSession: SparkSession) = {

    val dfClientes = rddstream.map(event => {
      //pongo como id de cliente y transaccion el codigo de cuenta
      Cliente(event(6).toInt, event(4).toString, event(6).toInt)
    })

    val dfTransacciones = rddstream.map(event => {
      //pongo como id de cliente y transaccion el codigo de cuenta
      Transaccion(event(6).toInt, event(2).toDouble, event(10).toString, "N/A", event(3).toString,
        Geolocalizacion(event(8).toDouble, event(9).toDouble, event(5).toString, "N/A"), event(0).toString)
    })

    val sc = sparkSession.sparkContext

    val dfClientesD = sparkSession.createDataFrame(dfClientes)
    val dfTransaccionesD = sparkSession.createDataFrame(dfTransacciones)

    dfClientesD.createOrReplaceGlobalTempView("CLIENTES")
    dfTransaccionesD.createOrReplaceGlobalTempView("TRANSACCIONES")

    //Tarea 5 Filtrar transacciones cuya categoria sea ocio
    val categoriaOcio = sparkSession.sql("SELECT t.dni, t.descripcion, t.importe FROM global_temp.TRANSACCIONES t WHERE t.descripcion LIKE '%Restaurant%' OR t.descripcion LIKE '%Sports%' OR t.descripcion LIKE '%Cinema%'")
    categoriaOcio

  }


  def transaccionesClientesDiasAtras(rddstream: RDD[Array[String]], sparkSession: SparkSession) = {

    val dfClientes = rddstream.map(event => {
      //pongo como id de cliente y transaccion el codigo de cuenta
      Cliente(event(6).toInt, event(4).toString, event(6).toInt)
    })

    val dfTransacciones = rddstream.map(event => {
      //pongo como id de cliente y transaccion el codigo de cuenta
      Transaccion(event(6).toInt, event(2).toDouble, event(10).toString, "N/A", event(3).toString,
        Geolocalizacion(event(8).toDouble, event(9).toDouble, event(5).toString, "N/A"), event(0).toString)
    })

    val sc = sparkSession.sparkContext

    val dfClientesD = sparkSession.createDataFrame(dfClientes)
    val dfTransaccionesD = sparkSession.createDataFrame(dfTransacciones)

    dfClientesD.createOrReplaceGlobalTempView("CLIENTES")
    dfTransaccionesD.createOrReplaceGlobalTempView("TRANSACCIONES")

    val transaccionesClientesDias = sparkSession.sql("SELECT c.nombre, t.fecha FROM global_temp.TRANSACCIONES t JOIN global_temp.CLIENTES c ON (t.dni=c.dni)" +
      "GROUP BY c.nombre, t.fecha HAVING TO_DATE(CAST(UNIX_TIMESTAMP(t.fecha, 'dd/MM/yyyy') AS TIMESTAMP)) >= TO_DATE(CAST(UNIX_TIMESTAMP(t.fecha, 'dd/MM/yyyy') AS TIMESTAMP))-30")
    transaccionesClientesDias

  }





}
