package com.keepcoding.batchlayer

import java.text.SimpleDateFormat
import java.util.Date

import com.keepcoding.dominio.{Cliente, Geolocalizacion, Transaccion}
import org.apache.spark.sql.SparkSession
import org.apache.spark.util.LongAccumulator
import com.databricks.spark.avro._


object MetricasSparkSQL {

  def run(args: Array[String]): Unit = {

    val sparkSession = SparkSession.builder().master("local[*]").appName("Batch Layer Spart Sql")
      .getOrCreate()

    import sparkSession.implicits._

    val rddTransacciones = sparkSession.read.csv(s"file:///${args(0)}")

    //Obtenemos cabecera
    val cabecera = rddTransacciones.first()
    //procesamos todas las lineas salvo la cabecera y hacemos un split de los campos por el separador coma
    val rddSinCabecera = rddTransacciones.filter(!_.equals(cabecera)).map(_.toString().split(","))
    //convertimos en un dataframe
    //creamos acumulador
    val acumulador: LongAccumulator = sparkSession.sparkContext.longAccumulator("dniCliente")
    val acumuladorTransaccion: LongAccumulator = sparkSession.sparkContext.longAccumulator("dniTransaccion")

    val dfClientes = rddSinCabecera.map(columna => {
      acumulador.add(1)
      Cliente(acumulador.value, columna(4), columna(6).toInt)
    })
    //veo los 10 primeros
    dfClientes.show(10)

    val formato = new SimpleDateFormat("d/M/yy H:mm")

    val dfTransacciones = rddSinCabecera.map(columna=> {
      acumuladorTransaccion.add(1)
      //var laFecha:java.util.Date = formato.parse(columna(0).trim)

      Transaccion(acumuladorTransaccion.value, columna(2).toDouble, columna(10), "N/A", columna(3),
        Geolocalizacion(columna(8).toDouble, columna(9).toDouble, columna(5), "N/A"),
        columna(0))
    })

    dfTransacciones.show(10)

    //Geolocalizacion(latitud:Double, longitud:Double, ciudad:String, pais:String)
    //Transaccion(dni:Long, importe:Double, descripcion:String, categoria:String, tarjetaCredito:String, geolocalizacion: Geolocalizacion)
    //Cliente(dni:Long, nombre:String, cuentaCorriente:String)

    //registro los dataframe como tablas
    dfClientes.createOrReplaceGlobalTempView("CLIENTES")
    dfTransacciones.createOrReplaceGlobalTempView("TRANSACCIONES")

    //Tarea 2 Agrupar transacciones y clientes por ciudad
    val transaccionesClientesCiudades = sparkSession.sql("SELECT c.nombre, TRIM(t.geolocalizacion.ciudad) AS ciudad, count(t.dni) AS transacciones  FROM global_temp.TRANSACCIONES t JOIN global_temp.CLIENTES c ON (t.dni=c.dni)" +
      "GROUP BY c.nombre, t.geolocalizacion.ciudad")
    transaccionesClientesCiudades.show(20)
    transaccionesClientesCiudades.write.format("com.databricks.spark.csv").save(s"file:///${args(1)}/transaccionesClientesCiudades.csv")

    //Tarea 3 Clientes con pagos superiores a 3000
    val pagosSuperiores = sparkSession.sql("SELECT c.nombre  FROM global_temp.TRANSACCIONES t JOIN global_temp.CLIENTES c ON (t.dni=c.dni)" +
      "WHERE t.importe > 3000 ORDER BY c.nombre")
    pagosSuperiores.show(20)
    pagosSuperiores.write.format("com.databricks.spark.csv").save(s"file:///${args(1)}/pagosSuperiores.csv")

    //Tarea 4 Transacciones por cliente con ciudad New York
    val clientesNewYork = sparkSession.sql("SELECT c.nombre, COUNT(t.dni)  FROM global_temp.TRANSACCIONES t JOIN global_temp.CLIENTES c ON (t.dni=c.dni) WHERE TRIM(t.geolocalizacion.ciudad) = 'New York' GROUP BY c.nombre")
    clientesNewYork.show(20)
    clientesNewYork.write.format("com.databricks.spark.csv").save(s"file:///${args(1)}/clientesNewYork.csv")

    //Tarea 5 Filtrar transacciones cuya categoria sea ocio
    val categoriaOcio = sparkSession.sql("SELECT t.dni, t.descripcion, t.importe FROM global_temp.TRANSACCIONES t WHERE t.descripcion LIKE '%Restaurant%' OR t.descripcion LIKE '%Sports%' OR t.descripcion LIKE '%Cinema%'")
    categoriaOcio.show(20)
    categoriaOcio.write.format("com.databricks.spark.avro").save(s"file:///${args(1)}/categoriaOcio.avro")
    //He intentado utilizar avro aqui pero me da un error, la verdad es que le he dado muchas vueltas fijandome que tenia importada la libreria
    //pero aun asi y buscandolo por internet no he podido dar con ello, pongo la sentencia no obstantes para poder saber que es lo que estoy haciendo erroneamente.

    //Agrupar las transacciones de cada cliente de los ultimos 30 dias
    val transaccionesClientesDias = sparkSession.sql("SELECT c.nombre, t.fecha FROM global_temp.TRANSACCIONES t JOIN global_temp.CLIENTES c ON (t.dni=c.dni)" +
      "GROUP BY c.nombre, t.fecha HAVING TO_DATE(CAST(UNIX_TIMESTAMP(t.fecha, 'dd/MM/yyyy') AS TIMESTAMP)) >= TO_DATE(CAST(UNIX_TIMESTAMP(t.fecha, 'dd/MM/yyyy') AS TIMESTAMP))-30")
    transaccionesClientesDias.write.format("com.databricks.spark.csv").save(s"file:///${args(1)}/transaccionesClientesDias.csv")

    sparkSession.close()


  }

}
