package com.keepcoding.speedlayer

import java.util.Properties

import com.keepcoding.dominio.{Cliente, Consultas, Geolocalizacion, Transaccion}
import org.apache.spark._
import org.apache.spark.streaming._
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.kafka.common.serialization.StringSerializer
import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.{DStream, InputDStream}
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord}
import org.apache.spark.sql.{Row, SparkSession}

import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global

object MetricasSparkStreaming extends App {


    val inputTopic = "ficherotransacciones"

    val conf = new SparkConf().setMaster("local[*]").setAppName("Practica Final Speedlayer")

    var kafkaParams = Map[String, Object](
      "bootstrap.servers" -> "localhost:9092",
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "group.id" -> "spark-demo",
      "kafka.consumer.id" -> "kafka-consumer-01"
    )

    val ssc = new StreamingContext(conf, Seconds(1))

    val inputEnBruto = KafkaUtils.createDirectStream(ssc, PreferConsistent,
      Subscribe[String, String](Array(inputTopic), kafkaParams))

    //val transaccionesStream = inputEnBruto.map(_.value())
    val transaccionesStream: DStream[String] = inputEnBruto.map(record => record.value())

    val separamosXcoma = transaccionesStream.map(_.split(","))


  //Pagos superiores a 3000
  separamosXcoma.foreachRDD{ rdd =>
    val spark = SparkSession.builder.config(rdd.sparkContext.getConf).getOrCreate()
    val losdataframe = new Consultas().pagoSuperiorA(rdd, spark)
    losdataframe.rdd.foreachPartition(escribirTopico("filtradoMayorD"))

  }

  //Agrupar transacciones clientes ciudad
  separamosXcoma.foreachRDD{ rdd =>
    val spark = SparkSession.builder.config(rdd.sparkContext.getConf).getOrCreate()
    val losdataframe = new Consultas().agruparTransaccionesClientesCiudad(rdd, spark)
    losdataframe.rdd.foreachPartition(escribirTopico("agruparTransaccionesClientesCiudad"))

  }

  //Transacciones clientes nueva york
  separamosXcoma.foreachRDD{ rdd =>
    val spark = SparkSession.builder.config(rdd.sparkContext.getConf).getOrCreate()
    val losdataframe = new Consultas().transaccionesClientesNuevaYork(rdd, spark)
    losdataframe.rdd.foreachPartition(escribirTopico("transaccionesClientesNuevaYork"))

  }

  //Transacciones categoria ocio
  separamosXcoma.foreachRDD{ rdd =>
    val spark = SparkSession.builder.config(rdd.sparkContext.getConf).getOrCreate()
    val losdataframe = new Consultas().transaccionesCategoriaOcio(rdd, spark)
    losdataframe.rdd.foreachPartition(escribirTopico("transaccionesCategoriaOcio"))

  }

  //Transacciones Clientes dias atras
  separamosXcoma.foreachRDD{ rdd =>
    val spark = SparkSession.builder.config(rdd.sparkContext.getConf).getOrCreate()
    val losdataframe = new Consultas().transaccionesClientesDiasAtras(rdd, spark)
    losdataframe.rdd.foreachPartition(escribirTopico("transaccionesClientesDiasAtras"))

  }



    Future {
      Thread.sleep(40000)
      ssc.stop(stopSparkContext = true, stopGracefully = true)
    }

    ssc.start()
    ssc.awaitTermination()




  def escribirTopico(topico: String)(partitionOfRecords: Iterator[Row]): Unit = {

    val producer = new KafkaProducer[String, String](getKafkaConfig())
    partitionOfRecords.foreach(data =>
      producer.send(new ProducerRecord[String, String](topico, data.toString())))
      producer.flush()
      producer.close()
  }


  def getKafkaConfig(): Properties = {
    val prop = new Properties()
    prop.put("bootstrap.servers", "localhost:9092")
    prop.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer")
    prop.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer")
    prop
  }




}


